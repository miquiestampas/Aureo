import { useEffect, useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";

// Lista de localidades de Madrid
const MADRID_LOCALITIES = [
  "Madrid",
  "Ajalvir",
  "Alcalá de Henares",
  "Alcobendas",
  "Alcorcón",
  "Aldea del Fresno",
  "Algete",
  "Alpedrete",
  "Aranjuez",
  "Arganda del Rey",
  "Arroyomolinos",
  "Becerril de la Sierra",
  "Boadilla del Monte",
  "Brunete",
  "Cercedilla",
  "Ciempozuelos",
  "Cobeña",
  "Collado Mediano",
  "Collado Villalba",
  "Colmenar de Oreja",
  "Colmenar Viejo",
  "Coslada",
  "Daganzo de Arriba",
  "El Álamo",
  "El Boalo",
  "El Escorial",
  "El Molar",
  "Fuenlabrada",
  "Fuente el Saz",
  "Galapagar",
  "Getafe",
  "Griñón",
  "Guadarrama",
  "Hoyo de Manzanares",
  "Humanes de Madrid",
  "Las Rozas",
  "Leganés",
  "Loeches",
  "Majadahonda",
  "Manzanares el Real",
  "Mejorada del Campo",
  "Moraleja de Enmedio",
  "Moralzarzal",
  "Móstoles",
  "Navacerrada",
  "Navalcarnero",
  "Paracuellos del Jarama",
  "Parla",
  "Pinto",
  "Pozuelo de Alarcón",
  "Rivas-Vaciamadrid",
  "San Agustín de Guadalix",
  "San Fernando de Henares",
  "San Lorenzo de El Escorial",
  "San Martín de la Vega",
  "San Martín de Valdeiglesias",
  "San Sebastián de los Reyes",
  "Sevilla la Nueva",
  "Soto del Real",
  "Torrejón de Ardoz",
  "Torrejón de la Calzada",
  "Torrelodones",
  "Torres de la Alameda",
  "Tres Cantos",
  "Valdemorillo",
  "Valdemoro",
  "Velilla de San Antonio",
  "Villalbilla",
  "Villanueva de la Cañada",
  "Villanueva del Pardillo",
  "Villarejo de Salvanés",
  "Villaviciosa de Odón"
];
import { 
  Card, CardContent, CardHeader, CardTitle, CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DataTable, SortableColumnHeader } from "@/components/ui/data-table";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  PlusCircle,
  Store,
  FileSpreadsheet,
  FileText,
  Pencil,
  Trash2,
  CheckCircle,
  XCircle,
  Info,
  Search,
  FileDown,
  Filter,
  Download,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { ColumnDef } from "@tanstack/react-table";

interface StoreData {
  id: number;
  code: string;
  name: string;
  type: string;
  district?: string; // Campo DISTRITO
  locality?: string; // Campo LOCALIDAD
  active: boolean;
  createdAt?: string | Date; // Fecha de grabación en el sistema
  // Campos adicionales
  address?: string;
  phone?: string;
  email?: string;
  cif?: string;
  businessName?: string;
  ownerName?: string;
  ownerIdNumber?: string;
  startDate?: string | Date;
  endDate?: string | Date;
  notes?: string;
}

// Form schema for creating/editing a store
const storeFormSchema = z.object({
  code: z.string().min(2, "El código debe tener al menos 2 caracteres").max(20, "El código debe tener máximo 20 caracteres"),
  name: z.string().min(2, "El nombre debe tener al menos 2 caracteres"),
  type: z.enum(["Excel", "PDF"]),
  district: z.string().optional(), // Campo DISTRITO
  locality: z.string().optional(), // Campo LOCALIDAD
  active: z.boolean().default(true),
  // Campos adicionales
  address: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().optional(),
  cif: z.string().optional(),
  businessName: z.string().optional(),
  ownerName: z.string().optional(),
  ownerIdNumber: z.string().optional(),
  startDate: z.string().optional().or(z.date().optional()),
  endDate: z.string().optional().or(z.date().optional()),
  notes: z.string().optional(),
});

type StoreFormValues = z.infer<typeof storeFormSchema>;

export default function StoreManagementPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const navigate = useLocation()[1];
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [selectedStore, setSelectedStore] = useState<StoreData | null>(null);
  const [isFilterExpanded, setIsFilterExpanded] = useState(false);
  const [isRecordsDialogOpen, setIsRecordsDialogOpen] = useState(false);

  // Estados para la visualización de archivos procesados
  const [storeActivities, setStoreActivities] = useState<any[]>([]);
  const [isLoadingActivities, setIsLoadingActivities] = useState(false);
  
  // Estados para importación de tiendas
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isImporting, setIsImporting] = useState(false);

  // Filtros
  const [codeFilter, setCodeFilter] = useState("");
  const [nameFilter, setNameFilter] = useState("");
  const [localityFilter, setLocalityFilter] = useState("_empty");
  const [districtFilter, setDistrictFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  // Referencias para exportación
  const tableRef = useRef(null);

  // Fetch all stores
  const { data: stores, refetch: refetchStores } = useQuery<StoreData[]>({
    queryKey: ['/api/stores'],
  });

  // Filtrado de tiendas
  const filteredStores = stores?.filter(store => {
    // Filtro por código
    if (codeFilter && !store.code.toLowerCase().includes(codeFilter.toLowerCase())) {
      return false;
    }

    // Filtro por nombre
    if (nameFilter && !store.name.toLowerCase().includes(nameFilter.toLowerCase())) {
      return false;
    }

    // Filtro por localidad
    if (localityFilter && localityFilter !== "_empty") {
      const matchesLocality = store.locality && 
        store.locality.toLowerCase().includes(localityFilter.toLowerCase());

      if (!matchesLocality) {
        return false;
      }
    }

    // Filtro por distrito
    if (districtFilter && 
        (!store.district || !store.district.toLowerCase().includes(districtFilter.toLowerCase()))) {
      return false;
    }

    // Filtro por tipo
    if (typeFilter !== "all" && store.type !== typeFilter) {
      return false;
    }

    // Filtro por estado
    if (statusFilter !== "all" && 
        ((statusFilter === "active" && !store.active) || 
         (statusFilter === "inactive" && store.active))) {
      return false;
    }

    return true;
  }) || [];

  // Métodos para exportación
  const exportToPDF = () => {
    if (!filteredStores.length) {
      toast({
        title: "No hay datos para exportar",
        description: "No se encontraron tiendas con los filtros actuales",
        variant: "destructive"
      });
      return;
    }

    const doc = new jsPDF();

    // Título
    doc.setFontSize(18);
    doc.text("Listado de Tiendas", 14, 22);

    // Filtros aplicados
    doc.setFontSize(11);
    let filterText = "Filtros aplicados: ";
    const filters = [];

    if (codeFilter) filters.push(`Código: ${codeFilter}`);
    if (nameFilter) filters.push(`Nombre: ${nameFilter}`);
    if (localityFilter && localityFilter !== "_empty") filters.push(`Localidad: ${localityFilter}`);
    if (districtFilter) filters.push(`Distrito: ${districtFilter}`);
    if (typeFilter !== "all") filters.push(`Tipo: ${typeFilter}`);
    if (statusFilter !== "all") filters.push(`Estado: ${statusFilter === "active" ? "Activo" : "Inactivo"}`);

    if (filters.length > 0) {
      doc.text(filterText + filters.join(", "), 14, 30);
    } else {
      doc.text("Sin filtros aplicados", 14, 30);
    }

    // Fecha de generación
    const now = new Date();
    doc.text(`Generado: ${now.toLocaleDateString()} ${now.toLocaleTimeString()}`, 14, 38);

    // Tabla
    autoTable(doc, {
      startY: 45,
      head: [["Código", "Nombre", "Tipo", "Fecha grabación", "Localidad", "Distrito", "Estado"]],
      body: filteredStores.map(store => [
        store.code,
        store.name,
        store.type,
        store.createdAt ? new Date(store.createdAt).toLocaleDateString('es-ES') : "—",
        store.locality || "—",
        store.district || "—",
        store.active ? "Activa" : "Inactiva"
      ]),
      theme: 'grid'
    });

    // Guardar el PDF
    doc.save("listado-tiendas.pdf");

    toast({
      title: "PDF exportado",
      description: "El listado de tiendas ha sido exportado correctamente"
    });
  };

  const exportToExcel = () => {
    if (!filteredStores.length) {
      toast({
        title: "No hay datos para exportar",
        description: "No se encontraron tiendas con los filtros actuales",
        variant: "destructive"
      });
      return;
    }

    // Preparar los datos
    const workbook = XLSX.utils.book_new();

    const worksheet = XLSX.utils.json_to_sheet(filteredStores.map(store => ({
      "Código": store.code,
      "Nombre": store.name,
      "Tipo": store.type,
      "Fecha grabación": store.createdAt ? new Date(store.createdAt).toLocaleDateString('es-ES') : "—",
      "Localidad": store.locality || "—",
      "Distrito": store.district || "—",
      "Estado": store.active ? "Activa" : "Inactiva",
      "Dirección": store.address || "—",
      "Teléfono": store.phone || "—",
      "Email": store.email || "—",
      "CIF": store.cif || "—",
      "Razón Social": store.businessName || "—",
      "Propietario": store.ownerName || "—"
    })));

    // Ajustar anchos de columna
    const columnWidths = [
      { wch: 10 }, // Código
      { wch: 25 }, // Nombre
      { wch: 10 }, // Tipo
      { wch: 15 }, // Fecha grabación
      { wch: 20 }, // Localidad
      { wch: 20 }, // Distrito
      { wch: 10 }, // Estado
      { wch: 30 }, // Dirección
      { wch: 15 }, // Teléfono
      { wch: 25 }, // Email
      { wch: 15 }, // CIF
      { wch: 25 }, // Razón Social
      { wch: 25 }, // Propietario
    ];

    worksheet["!cols"] = columnWidths;

    // Añadir la hoja al libro
    XLSX.utils.book_append_sheet(workbook, worksheet, "Tiendas");

    // Guardar el archivo
    XLSX.writeFile(workbook, "listado-tiendas.xlsx");

    toast({
      title: "Excel exportado",
      description: "El listado de tiendas ha sido exportado correctamente"
    });
  };

  // Create store form
  const createForm = useForm<StoreFormValues>({
    resolver: zodResolver(storeFormSchema),
    defaultValues: {
      code: "",
      name: "",
      type: "Excel",
      district: "",
      locality: "",
      active: true,
      address: "",
      phone: "",
      email: "",
      cif: "",
      businessName: "",
      ownerName: "",
      ownerIdNumber: "",
      notes: "",
    },
  });

  // Edit store form
  const editForm = useForm<StoreFormValues>({
    resolver: zodResolver(storeFormSchema),
    defaultValues: {
      code: "",
      name: "",
      type: "Excel",
      district: "",
      locality: "",
      active: true,
      address: "",
      phone: "",
      email: "",
      cif: "",
      businessName: "",
      ownerName: "",
      ownerIdNumber: "",
      notes: "",
    },
  });

  // Set edit form values when a store is selected
  useEffect(() => {
    if (selectedStore && isEditDialogOpen) {
      editForm.reset({
        code: selectedStore.code,
        name: selectedStore.name,
        type: selectedStore.type as "Excel" | "PDF",
        district: selectedStore.district || "",
        locality: selectedStore.locality || "",
        active: selectedStore.active,
        address: selectedStore.address || "",
        phone: selectedStore.phone || "",
        email: selectedStore.email || "",
        cif: selectedStore.cif || "",
        businessName: selectedStore.businessName || "",
        ownerName: selectedStore.ownerName || "",
        ownerIdNumber: selectedStore.ownerIdNumber || "",
        startDate: selectedStore.startDate ? selectedStore.startDate : "",
        endDate: selectedStore.endDate ? selectedStore.endDate : "",
        notes: selectedStore.notes || "",
      });
    }
  }, [selectedStore, isEditDialogOpen, editForm]);

  // Create store mutation
  const createMutation = useMutation({
    mutationFn: async (data: StoreFormValues) => {
      const response = await apiRequest("POST", "/api/stores", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Tienda creada",
        description: "La tienda ha sido creada correctamente.",
      });
      setIsCreateDialogOpen(false);
      createForm.reset();
      refetchStores();
    },
    onError: (error: Error) => {
      toast({
        title: "Error al crear tienda",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update store mutation
  const updateMutation = useMutation({
    mutationFn: async (data: StoreFormValues & { id: number }) => {
      const { id, ...storeData } = data;
      const response = await apiRequest("PUT", `/api/stores/${id}`, storeData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Tienda actualizada",
        description: "La tienda ha sido actualizada correctamente.",
      });
      setIsEditDialogOpen(false);
      setSelectedStore(null);
      refetchStores();
    },
    onError: (error: Error) => {
      toast({
        title: "Error al actualizar tienda",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete store mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/stores/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Tienda eliminada",
        description: "La tienda ha sido eliminada correctamente.",
      });
      setIsDeleteDialogOpen(false);
      setSelectedStore(null);
      refetchStores();
    },
    onError: (error: Error) => {
      toast({
        title: "Error al eliminar tienda",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle create form submission
  const onCreateSubmit = (data: StoreFormValues) => {
    // Convertir "_empty" a cadena vacía
    const processedData = {
      ...data,
      locality: data.locality === "_empty" ? "" : data.locality
    };
    createMutation.mutate(processedData);
  };

  // Handle edit form submission
  const onEditSubmit = (data: StoreFormValues) => {
    if (!selectedStore) return;

    // Convertir "_empty" a cadena vacía
    const processedData = {
      ...data,
      locality: data.locality === "_empty" ? "" : data.locality
    };

    updateMutation.mutate({
      id: selectedStore.id,
      ...processedData,
    });
  };

  // Handle delete confirmation
  const confirmDelete = () => {
    if (!selectedStore) return;
    deleteMutation.mutate(selectedStore.id);
  };

  // Open edit dialog for a store
  const handleEditStore = (store: StoreData) => {
    setSelectedStore(store);
    setIsEditDialogOpen(true);
  };

  // Open delete dialog for a store
  const handleDeleteStore = (store: StoreData) => {
    setSelectedStore(store);
    setIsDeleteDialogOpen(true);
  };

  // Open detail dialog for a store
  const handleViewStoreDetails = (store: StoreData) => {
    setSelectedStore(store);
    setIsDetailDialogOpen(true);
  };

  // Cargar archivos procesados de tienda en un diálogo
  const handleViewStoreRecords = async (store: StoreData) => {
    setSelectedStore(store);
    setIsRecordsDialogOpen(true);

    // Cargar actividades de archivos para la tienda
    setIsLoadingActivities(true);
    try {
      const response = await fetch(`/api/file-activities?storeCode=${store.code}`);
      if (!response.ok) {
        throw new Error("Error al cargar las actividades de archivos");
      }
      const data = await response.json();
      setStoreActivities(data);
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Error al cargar las actividades de archivos",
        variant: "destructive",
      });
      setStoreActivities([]);
    } finally {
      setIsLoadingActivities(false);
    }
  };
  
  // Descargar plantilla Excel para importación de tiendas
  const downloadTemplateExcel = () => {
    // Crear un libro Excel nuevo
    const workbook = XLSX.utils.book_new();
    
    // Preparar los datos de ejemplo
    const exampleData = [
      {
        "Código*": "ST001",
        "Nombre*": "Tienda Ejemplo",
        "Tipo*": "Excel",
        "Localidad": "Madrid",
        "Distrito": "Centro",
        "Activa*": "Sí",
        "Dirección": "Calle Ejemplo 123",
        "Teléfono": "912345678",
        "Email": "tienda@ejemplo.com",
        "CIF": "B12345678",
        "Razón Social": "Empresa Ejemplo S.L.",
        "Nombre Propietario": "Juan Pérez",
        "DNI Propietario": "12345678A",
        "Fecha Inicio": "01/01/2023",
        "Fecha Cese": "",
        "Anotaciones": "Notas de ejemplo"
      },
      {
        "Código*": "",
        "Nombre*": "",
        "Tipo*": "",
        "Localidad": "",
        "Distrito": "",
        "Activa*": "",
        "Dirección": "",
        "Teléfono": "",
        "Email": "",
        "CIF": "",
        "Razón Social": "",
        "Nombre Propietario": "",
        "DNI Propietario": "",
        "Fecha Inicio": "",
        "Fecha Cese": "",
        "Anotaciones": ""
      }
    ];
    
    // Crear la hoja de trabajo y añadir los datos
    const worksheet = XLSX.utils.json_to_sheet(exampleData);
    
    // Ajustar anchos de columna
    const columnWidths = [
      { wch: 12 }, // Código
      { wch: 25 }, // Nombre
      { wch: 10 }, // Tipo
      { wch: 20 }, // Localidad
      { wch: 20 }, // Distrito
      { wch: 10 }, // Activa
      { wch: 30 }, // Dirección
      { wch: 15 }, // Teléfono
      { wch: 25 }, // Email
      { wch: 15 }, // CIF
      { wch: 25 }, // Razón Social
      { wch: 25 }, // Nombre Propietario
      { wch: 15 }, // DNI Propietario
      { wch: 15 }, // Fecha Inicio
      { wch: 15 }, // Fecha Cese
      { wch: 40 }, // Anotaciones
    ];
    
    worksheet["!cols"] = columnWidths;
    
    // Añadir pestaña de instrucciones
    const instructionsData = [
      ["INSTRUCCIONES PARA COMPLETAR LA PLANTILLA"],
      [""],
      ["1. Los campos marcados con * son obligatorios."],
      ["2. Valores para el campo 'Tipo': 'Excel' o 'PDF'"],
      ["3. Valores para el campo 'Activa': 'Sí' o 'No'"],
      ["4. Formato de fechas: DD/MM/AAAA"],
      ["5. No elimine la fila de ejemplo, puede utilizarla como guía."],
      ["6. No modifique los nombres de las columnas."],
      [""],
      ["NOTAS IMPORTANTES:"],
      ["- El código de tienda debe ser único."],
      ["- Asegúrese de guardar el archivo en formato .xlsx antes de cargarlo."]
    ];
    
    const instructionsSheet = XLSX.utils.aoa_to_sheet(instructionsData);
    
    // Añadir las hojas al libro
    XLSX.utils.book_append_sheet(workbook, instructionsSheet, "Instrucciones");
    XLSX.utils.book_append_sheet(workbook, worksheet, "Tiendas");
    
    // Guardar el archivo
    XLSX.writeFile(workbook, "plantilla-importacion-tiendas.xlsx");
    
    toast({
      title: "Plantilla descargada",
      description: "La plantilla para importación de tiendas ha sido descargada correctamente"
    });
  };
  
  // Manejar cambios en el archivo seleccionado para importar
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setUploadedFile(e.target.files[0]);
    }
  };
  
  // Procesar la importación de tiendas desde Excel
  const handleImportStores = async () => {
    if (!uploadedFile) {
      toast({
        title: "Error",
        description: "Debe seleccionar un archivo Excel para importar",
        variant: "destructive"
      });
      return;
    }
    
    setIsImporting(true);
    
    // Crear un FormData para enviar el archivo
    const formData = new FormData();
    formData.append("file", uploadedFile);
    
    try {
      const response = await fetch("/api/import-stores", {
        method: "POST",
        body: formData
      });
      
      if (!response.ok) {
        throw new Error("Error al importar tiendas");
      }
      
      const result = await response.json();
      
      toast({
        title: "Importación exitosa",
        description: `Se importaron ${result.imported} tiendas correctamente.`,
      });
      
      // Cerrar el diálogo y limpiar el estado
      setIsImportDialogOpen(false);
      setUploadedFile(null);
      refetchStores();
      
    } catch (error) {
      toast({
        title: "Error en la importación",
        description: error instanceof Error ? error.message : "Error al importar tiendas desde Excel",
        variant: "destructive",
      });
    } finally {
      setIsImporting(false);
    }
  };

  // Check if user can edit/delete (only SuperAdmin and Admin)
  const canModify = user?.role === "SuperAdmin" || user?.role === "Admin";

  // Data table columns
  const columns: ColumnDef<StoreData>[] = [
    {
      accessorKey: "code",
      header: ({ column }) => <SortableColumnHeader column={column} title="Código" />,
      enableSorting: true
    },
    {
      accessorKey: "name",
      header: ({ column }) => <SortableColumnHeader column={column} title="Nombre" />,
      enableSorting: true
    },
    {
      accessorKey: "type",
      header: ({ column }) => <SortableColumnHeader column={column} title="Tipo" />,
      cell: ({ row }) => {
        const type = row.original.type;
        return (
          <div className="flex items-center">
            {type === "Excel" ? (
              <FileSpreadsheet className="h-4 w-4 mr-2 text-green-500" />
            ) : (
              <FileText className="h-4 w-4 mr-2 text-red-500" />
            )}
            {type}
          </div>
        );
      },
      enableSorting: true
    },
    {
      id: "createdAt",
      accessorFn: (row) => row.createdAt ? new Date(row.createdAt) : null,
      header: ({ column }) => <SortableColumnHeader column={column} title="Fecha grabación" />,
      cell: ({ row }) => {
        const createdAt = row.original.createdAt;
        if (!createdAt) return "—";
        
        // Formatear la fecha como DD/MM/YYYY
        const date = new Date(createdAt);
        return date.toLocaleDateString('es-ES', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric'
        });
      },
      enableSorting: true
    },
    {
      id: "locality",
      accessorFn: (row) => row.locality || "—",
      header: ({ column }) => <SortableColumnHeader column={column} title="Localidad" />,
      cell: ({ row }) => {
        const store = row.original;
        return store.locality || "—";
      },
      enableSorting: true
    },
    {
      id: "district",
      accessorFn: (row) => row.district || "—",
      header: ({ column }) => <SortableColumnHeader column={column} title="Distrito" />,
      cell: ({ row }) => {
        const store = row.original;
        return store.district || "—";
      },
      enableSorting: true
    },
    {
      accessorKey: "active",
      header: ({ column }) => <SortableColumnHeader column={column} title="Estado" />,
      cell: ({ row }) => {
        const isActive = row.original.active;
        return isActive ? (
          <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
            <CheckCircle className="h-3 w-3 mr-1" /> Activa
          </Badge>
        ) : (
          <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">
            <XCircle className="h-3 w-3 mr-1" /> Inactiva
          </Badge>
        );
      },
      enableSorting: true
    },
    ...(canModify ? [
      {
        id: "actions",
        header: "Acciones",
        cell: ({ row }: any) => {
          const store = row.original;
          return (
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="h-8 w-8 p-0 text-blue-500 hover:text-blue-600" 
                onClick={() => handleViewStoreDetails(store)}
                title="Ver Detalles"
              >
                <Info className="h-4 w-4" />
                <span className="sr-only">Ver Detalles</span>
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="h-8 w-8 p-0 text-green-500 hover:text-green-600" 
                onClick={() => handleViewStoreRecords(store)}
                title="Ver Registros"
              >
                <FileText className="h-4 w-4" />
                <span className="sr-only">Ver Registros</span>
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="h-8 w-8 p-0" 
                onClick={() => handleEditStore(store)}
                title="Editar"
              >
                <Pencil className="h-4 w-4" />
                <span className="sr-only">Editar</span>
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="h-8 w-8 p-0 text-red-500 hover:text-red-600" 
                onClick={() => handleDeleteStore(store)}
                title="Eliminar"
              >
                <Trash2 className="h-4 w-4" />
                <span className="sr-only">Eliminar</span>
              </Button>
            </div>
          );
        }
      }
    ] : []),
  ];

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Gestión de Tiendas</h1>
            <p className="text-gray-500 mt-1">Administre sus tiendas de Excel y PDF</p>
          </div>

          {canModify && 
            <div className="flex space-x-2">
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary hover:bg-primary/90">
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Añadir Nueva Tienda
                  </Button>
                </DialogTrigger>
              </Dialog>
              
              <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="border-primary text-primary hover:bg-primary/10">
                    <FileSpreadsheet className="mr-2 h-4 w-4" />
                    Importar Tiendas
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[550px]">
                  <DialogHeader>
                    <DialogTitle>Importar Tiendas desde Excel</DialogTitle>
                    <DialogDescription>
                      Utilice una plantilla Excel para importar múltiples tiendas a la vez.
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="py-6 space-y-4">
                    <div className="bg-muted/30 rounded-lg p-4 border border-dashed">
                      <h3 className="font-medium mb-2">Instrucciones de uso:</h3>
                      <ol className="list-decimal list-inside text-sm space-y-2">
                        <li>Descargue la plantilla Excel haciendo clic en el botón de abajo</li>
                        <li>Complete la información de cada tienda en la plantilla</li>
                        <li>Guarde el archivo y cárguelo con el botón "Seleccionar Archivo"</li>
                        <li>Verifique que toda la información sea correcta antes de importar</li>
                      </ol>
                    </div>
                    
                    <div className="flex flex-col space-y-4">
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={downloadTemplateExcel}
                        type="button"
                      >
                        <FileDown className="mr-2 h-4 w-4" />
                        Descargar Plantilla
                      </Button>
                      
                      <div className="border rounded-md p-4">
                        <label className="block text-sm font-medium mb-2">
                          Seleccione el archivo Excel con los datos
                        </label>
                        <Input
                          type="file"
                          accept=".xlsx,.xls"
                          className="mb-2"
                          onChange={handleFileChange}
                        />
                        {uploadedFile && (
                          <p className="text-sm text-green-600">
                            Archivo seleccionado: {uploadedFile.name}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button variant="outline" onClick={() => {
                      setIsImportDialogOpen(false);
                      setUploadedFile(null);
                    }}>
                      Cancelar
                    </Button>
                    <Button 
                      className="bg-primary hover:bg-primary/90"
                      onClick={handleImportStores}
                      disabled={isImporting || !uploadedFile}
                    >
                      {isImporting ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Importando...
                        </>
                      ) : (
                        <>Importar Tiendas</>
                      )}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          }

          {/* Dialog para crear tienda */}
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogContent className="sm:max-w-[700px] max-h-[85vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Crear Nueva Tienda</DialogTitle>
                <DialogDescription>
                  Añadir una nueva tienda al sistema.
                </DialogDescription>
              </DialogHeader>

                <Form {...createForm}>
                  <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-4 py-4">
                    <FormField
                      control={createForm.control}
                      name="code"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Código de Tienda</FormLabel>
                          <FormControl>
                            <Input placeholder="Ej: ST001" {...field} />
                          </FormControl>
                          <FormDescription>
                            Un identificador único para la tienda
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={createForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nombre de Tienda</FormLabel>
                          <FormControl>
                            <Input placeholder="Ej: Tienda Principal" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={createForm.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tipo de Tienda</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Seleccione tipo de tienda" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Excel">Tienda Excel</SelectItem>
                              <SelectItem value="PDF">Tienda PDF</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Determina cómo se procesan los datos de la tienda
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={createForm.control}
                        name="locality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Localidad</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              value={field.value || ""}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Seleccione localidad" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="_empty">Sin especificar</SelectItem>
                                {MADRID_LOCALITIES.map((locality) => (
                                  <SelectItem key={locality} value={locality}>
                                    {locality}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={createForm.control}
                        name="district"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Distrito</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              value={field.value || ""}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Seleccione distrito" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="_empty">Sin especificar</SelectItem>
                                <SelectItem value="Arganzuela">Arganzuela</SelectItem>
                                <SelectItem value="Barajas">Barajas</SelectItem>
                                <SelectItem value="Carabanchel">Carabanchel</SelectItem>
                                <SelectItem value="Centro">Centro</SelectItem>
                                <SelectItem value="Chamartín">Chamartín</SelectItem>
                                <SelectItem value="Chamberí">Chamberí</SelectItem>
                                <SelectItem value="Ciudad Lineal">Ciudad Lineal</SelectItem>
                                <SelectItem value="Fuencarral-El Pardo">Fuencarral-El Pardo</SelectItem>
                                <SelectItem value="Hortaleza">Hortaleza</SelectItem>
                                <SelectItem value="Latina">Latina</SelectItem>
                                <SelectItem value="Moncloa-Aravaca">Moncloa-Aravaca</SelectItem>
                                <SelectItem value="Moratalaz">Moratalaz</SelectItem>
                                <SelectItem value="Puente de Vallecas">Puente de Vallecas</SelectItem>
                                <SelectItem value="Retiro">Retiro</SelectItem>
                                <SelectItem value="Salamanca">Salamanca</SelectItem>
                                <SelectItem value="San Blas-Vicálvaro">San Blas-Vicálvaro</SelectItem>
                                <SelectItem value="Tetuán">Tetuán</SelectItem>
                                <SelectItem value="Usera-Villaverde">Usera-Villaverde</SelectItem>
                                <SelectItem value="Villa de Vallecas">Villa de Vallecas</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={createForm.control}
                      name="active"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">Estado Activo</FormLabel>
                            <FormDescription>
                              Las tiendas activas procesarán nuevos archivos
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    {/* Nuevos campos - Información adicional */}
                    <div className="border rounded-md p-4 mt-6">
                      <h3 className="font-medium mb-3">Información Adicional</h3>

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={createForm.control}
                          name="address"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Dirección</FormLabel>
                              <FormControl>
                                <Input placeholder="Ej: Calle Principal 123" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={createForm.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Teléfono</FormLabel>
                              <FormControl>
                                <Input placeholder="Ej: 912 345 678" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4 mt-4">
                        <FormField
                          control={createForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Correo Electrónico</FormLabel>
                              <FormControl>
                                <Input placeholder="Ej: tienda@ejemplo.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={createForm.control}
                          name="cif"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>CIF</FormLabel>
                              <FormControl>
                                <Input placeholder="Ej: B12345678" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4 mt-4">
                        <FormField
                          control={createForm.control}
                          name="businessName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Razón Social</FormLabel>
                              <FormControl>
                                <Input placeholder="Ej: Empresa S.L." {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={createForm.control}
                          name="ownerName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Nombre del Propietario</FormLabel>
                              <FormControl>
                                <Input placeholder="Ej: Juan Pérez" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4 mt-4">
                        <FormField
                          control={createForm.control}
                          name="ownerIdNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>DNI del Propietario</FormLabel>
                              <FormControl>
                                <Input placeholder="Ej: 12345678A" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={createForm.control}
                          name="startDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Fecha de Inicio de Actividad</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} value={field.value ? new Date(field.value).toISOString().split('T')[0] : ''} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4 mt-4">
                        <FormField
                          control={createForm.control}
                          name="endDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Fecha de Cese (si es inactiva)</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} value={field.value ? new Date(field.value).toISOString().split('T')[0] : ''} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="mt-4">
                        <FormField
                          control={createForm.control}
                          name="notes"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Anotaciones</FormLabel>
                              <FormControl>
                                <textarea 
                                  className="flex min-h-20 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" 
                                  placeholder="Información adicional relevante..."
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>

                    <DialogFooter>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setIsCreateDialogOpen(false)}
                      >
                        Cancelar
                      </Button>
                      <Button 
                        type="submit"
                        disabled={createMutation.isPending}
                      >
                        {createMutation.isPending ? "Creando..." : "Crear Tienda"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          
        </div>

        {/* Advanced Filter and Export */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Filter className="h-5 w-5 mr-2 text-primary" />
                <CardTitle>Filtros Avanzados</CardTitle>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setIsFilterExpanded(!isFilterExpanded)}
                className="text-gray-500"
              >
                {isFilterExpanded ? (
                  <><ChevronUp className="h-4 w-4 mr-1" /> Ocultar</>
                ) : (
                  <><ChevronDown className="h-4 w-4 mr-1" /> Mostrar</>
                )}
              </Button>
            </div>
          </CardHeader>

          {isFilterExpanded && (
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <Label htmlFor="code-filter">Código</Label>
                  <div className="flex mt-1">
                    <Input
                      id="code-filter"
                      placeholder="Buscar por código"
                      value={codeFilter}
                      onChange={(e) => setCodeFilter(e.target.value)}
                      className="flex-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="name-filter">Nombre</Label>
                  <div className="flex mt-1">
                    <Input
                      id="name-filter"
                      placeholder="Buscar por nombre"
                      value={nameFilter}
                      onChange={(e) => setNameFilter(e.target.value)}
                      className="flex-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="locality-filter">Localidad</Label>
                  <div className="flex mt-1">
                    <Select
                      value={localityFilter}
                      onValueChange={setLocalityFilter}
                    >
                      <SelectTrigger id="locality-filter" className="flex-1">
                        <SelectValue placeholder="Todas las localidades" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="_empty">Todas las localidades</SelectItem>
                        {MADRID_LOCALITIES.map((locality) => (
                          <SelectItem key={locality} value={locality}>
                            {locality}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="district-filter">Distrito</Label>
                  <div className="flex mt-1">
                    <Input
                      id="district-filter"
                      placeholder="Buscar por distrito"
                      value={districtFilter}
                      onChange={(e) => setDistrictFilter(e.target.value)}
                      className="flex-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="type-filter">Tipo</Label>
                  <div className="flex mt-1">
                    <Select
                      value={typeFilter}
                      onValueChange={setTypeFilter}
                    >
                      <SelectTrigger id="type-filter" className="flex-1">
                        <SelectValue placeholder="Todos los tipos" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos los tipos</SelectItem>
                        <SelectItem value="Excel">Excel</SelectItem>
                        <SelectItem value="PDF">PDF</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="status-filter">Estado</Label>
                  <div className="flex mt-1">
                    <Select
                      value={statusFilter}
                      onValueChange={setStatusFilter}
                    >
                      <SelectTrigger id="status-filter" className="flex-1">
                        <SelectValue placeholder="Todos los estados" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos los estados</SelectItem>
                        <SelectItem value="active">Activas</SelectItem>
                        <SelectItem value="inactive">Inactivas</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center mt-6">
                <div className="text-sm text-gray-500">
                  {filteredStores.length} {filteredStores.length === 1 ? 'tienda encontrada' : 'tiendas encontradas'}
                </div>

                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setCodeFilter("");
                      setNameFilter("");
                      setLocalityFilter("_empty");
                      setDistrictFilter("");
                      setTypeFilter("all");
                      setStatusFilter("all");
                    }}
                  >
                    Limpiar Filtros
                  </Button>

                  <Button 
                    variant="outline" 
                    className="bg-green-50 text-green-700 hover:bg-green-100 hover:text-green-800 border-green-200"
                    onClick={exportToExcel}
                  >
                    <FileSpreadsheet className="h-4 w-4 mr-2" />
                    Exportar Excel
                  </Button>

                  <Button 
                    variant="outline" 
                    className="bg-red-50 text-red-700 hover:bg-red-100 hover:text-red-800 border-red-200"
                    onClick={exportToPDF}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Exportar PDF
                  </Button>
                </div>
              </div>
            </CardContent>
          )}
        </Card>

        {/* Stores Table */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Store className="h-5 w-5 mr-2 text-primary" />
                <CardTitle>Todas las Tiendas</CardTitle>
              </div>

              {!isFilterExpanded && (
                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    className="bg-green-50 text-green-700 hover:bg-green-100 hover:text-green-800 border-green-200"
                    onClick={exportToExcel}
                  >
                    <FileSpreadsheet className="h-4 w-4 mr-2" />
                    Exportar Excel
                  </Button>

                  <Button 
                    variant="outline" 
                    className="bg-red-50 text-red-700 hover:bg-red-100 hover:text-red-800 border-red-200"
                    onClick={exportToPDF}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Exportar PDF
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-0" ref={tableRef}>
            {filteredStores.length ? (
              <DataTable
                columns={columns}
                data={filteredStores}
                searchKey="name"
              />
            ) : (
              <div className="flex flex-col items-center justify-center py-12">
                <Store className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No se encontraron tiendas</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  {codeFilter || nameFilter || localityFilter || districtFilter || typeFilter !== "all" || statusFilter !== "all"
                    ? "Ajuste los filtros para ver resultados."
                    : "Cree una nueva tienda para comenzar."
                  }
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Edit Store Dialog */}
        {selectedStore && (
          <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
            <DialogContent className="max-w-5xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Editar Tienda</DialogTitle>
                <DialogDescription>
                  Actualizar la información de la tienda.
                </DialogDescription>
              </DialogHeader>

              <Form {...editForm}>
                <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="grid grid-cols-2 gap-6 py-4">
                  <div className="space-y-4">
                    <FormField
                      control={editForm.control}
                      name="code"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Código de Tienda</FormLabel>
                          <FormControl>
                            <Input placeholder="Ej: ST001" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={editForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nombre de Tienda</FormLabel>
                          <FormControl>
                            <Input placeholder="Ej: Tienda Principal" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={editForm.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tipo de Tienda</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Seleccione tipo de tienda" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Excel">Tienda Excel</SelectItem>
                              <SelectItem value="PDF">Tienda PDF</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={editForm.control}
                        name="locality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Localidad</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            value={field.value || ""}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Seleccione localidad" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="_empty">Sin especificar</SelectItem>
                              {MADRID_LOCALITIES.map((locality) => (
                                <SelectItem key={locality} value={locality}>
                                  {locality}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={editForm.control}
                      name="district"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Distrito</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            value={field.value || ""}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Seleccione distrito" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="_empty">Sin especificar</SelectItem>
                              <SelectItem value="Arganzuela">Arganzuela</SelectItem>
                              <SelectItem value="Barajas">Barajas</SelectItem>
                              <SelectItem value="Carabanchel">Carabanchel</SelectItem>
                              <SelectItem value="Centro">Centro</SelectItem>
                              <SelectItem value="Chamartín">Chamartín</SelectItem>
                              <SelectItem value="Chamberí">Chamberí</SelectItem>
                              <SelectItem value="Ciudad Lineal">Ciudad Lineal</SelectItem>
                              <SelectItem value="Fuencarral-El Pardo">Fuencarral-El Pardo</SelectItem>
                              <SelectItem value="Hortaleza">Hortaleza</SelectItem>
                              <SelectItem value="Latina">Latina</SelectItem>
                              <SelectItem value="Moncloa-Aravaca">Moncloa-Aravaca</SelectItem>
                              <SelectItem value="Moratalaz">Moratalaz</SelectItem>
                              <SelectItem value="Puente de Vallecas">Puente de Vallecas</SelectItem>
                              <SelectItem value="Retiro">Retiro</SelectItem>
                              <SelectItem value="Salamanca">Salamanca</SelectItem>
                              <SelectItem value="San Blas-Vicálvaro">San Blas-Vicálvaro</SelectItem>
                              <SelectItem value="Tetuán">Tetuán</SelectItem>
                              <SelectItem value="Usera-Villaverde">Usera-Villaverde</SelectItem>
                              <SelectItem value="Villa de Vallecas">Villa de Vallecas</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={editForm.control}
                    name="active"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between col-span-3 space-x-2 p-3 border rounded-md bg-muted/10">
                        <div className="space-y-0.5">
                          <FormLabel>Estado de la Tienda</FormLabel>
                          <FormDescription>
                            Activar o desactivar el procesamiento de archivos para esta tienda
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {/* Nuevos campos - Información adicional */}
                  <div className="border rounded-md p-4 mt-6">
                    <h3 className="font-medium mb-3">Información Adicional</h3>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={editForm.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Dirección</FormLabel>
                            <FormControl>
                              <Input placeholder="Ej: Calle Principal 123" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={editForm.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Teléfono</FormLabel>
                            <FormControl>
                              <Input placeholder="Ej: 912 345 678" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <FormField
                        control={editForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Correo Electrónico</FormLabel>
                            <FormControl>
                              <Input placeholder="Ej: tienda@ejemplo.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={editForm.control}
                        name="cif"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CIF</FormLabel>
                            <FormControl>
                              <Input placeholder="Ej: B12345678" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <FormField
                        control={editForm.control}
                        name="businessName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Razón Social</FormLabel>
                            <FormControl>
                              <Input placeholder="Ej: Empresa S.L." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={editForm.control}
                        name="ownerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nombre del Propietario</FormLabel>
                            <FormControl>
                              <Input placeholder="Ej: Juan Pérez" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <FormField
                        control={editForm.control}
                        name="ownerIdNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>DNI del Propietario</FormLabel>
                            <FormControl>
                              <Input placeholder="Ej: 12345678A" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={editForm.control}
                        name="startDate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Fecha de Inicio de Actividad</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} value={field.value ? new Date(field.value).toISOString().split('T')[0] : ''} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <FormField
                        control={editForm.control}
                        name="endDate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Fecha de Cese (si es inactiva)</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} value={field.value ? new Date(field.value).toISOString().split('T')[0] : ''} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="mt-4">
                      <FormField
                        control={editForm.control}
                        name="notes"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Anotaciones</FormLabel>
                            <FormControl>
                              <textarea 
                                className="flex min-h-20 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" 
                                placeholder="Información adicional relevante..."
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                </div>

                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsEditDialogOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button 
                    type="submit"
                    disabled={updateMutation.isPending}
                  >
                    {updateMutation.isPending ? "Actualizando..." : "Actualizar Tienda"}
                  </Button>
                </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        )}

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Está seguro?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción eliminará permanentemente la tienda "{selectedStore?.name}". 
                Esta acción no se puede deshacer.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction 
                onClick={confirmDelete}
                className="bg-red-600 hover:bg-red-700 focus:ring-red-600"
              >
                {deleteMutation.isPending ? "Eliminando..." : "Eliminar"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Store Details Dialog */}
        {selectedStore && (
          <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
            <DialogContent className="max-w-4xl">
              <DialogHeader>
                <DialogTitle className="text-xl flex items-center">
                  <Store className="h-5 w-5 mr-2 text-primary" />
                  Detalles de Tienda: {selectedStore.name}
                </DialogTitle>
                <DialogDescription>
                  Información completa de la tienda
                </DialogDescription>
              </DialogHeader>

              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="border rounded-md p-4">
                    <h3 className="font-medium mb-3 border-b pb-2">Información Básica</h3>

                    <div className="space-y-2">
                      <div>
                        <span className="font-medium">Código:</span> 
                        <span className="ml-2">{selectedStore.code}</span>
                      </div>
                      <div>
                        <span className="font-medium">Nombre:</span> 
                        <span className="ml-2">{selectedStore.name}</span>
                      </div>
                      <div>
                        <span className="font-medium">Tipo:</span> 
                        <span className="ml-2 flex items-center">
                          {selectedStore.type === "Excel" ? (
                            <><FileSpreadsheet className="h-4 w-4 mr-1 text-green-500" /> Excel</>
                          ) : (
                            <><FileText className="h-4 w-4 mr-1 text-red-500" /> PDF</>
                          )}
                        </span>
                      </div>
                      <div>
                        <span className="font-medium">Localidad:</span> 
                        <span className="ml-2">{selectedStore.locality || "—"}</span>
                      </div>
                      <div>
                        <span className="font-medium">Distrito:</span> 
                        <span className="ml-2">{selectedStore.district || "—"}</span>
                      </div>
                      <div>
                        <span className="font-medium">Estado:</span> 
                        <span className="ml-2">
                          {selectedStore.active ? (
                            <Badge variant="outline" className="bg-green-100 text-green-800">
                              <CheckCircle className="h-3 w-3 mr-1" /> Activa
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-red-100 text-red-800">
                              <XCircle className="h-3 w-3 mr-1" /> Inactiva
                            </Badge>
                          )}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="border rounded-md p-4">
                    <h3 className="font-medium mb-3 border-b pb-2">Fechas</h3>

                    <div className="space-y-2">
                      <div>
                        <span className="font-medium">Fecha de grabación:</span> 
                        <span className="ml-2">
                          {selectedStore.createdAt 
                            ? new Date(selectedStore.createdAt).toLocaleDateString('es-ES', {
                                day: '2-digit',
                                month: '2-digit',
                                year: 'numeric'
                              }) 
                            : "—"}
                        </span>
                      </div>
                      <div>
                        <span className="font-medium">Fecha de inicio:</span> 
                        <span className="ml-2">
                          {selectedStore.startDate 
                            ? new Date(selectedStore.startDate).toLocaleDateString() 
                            : "—"}
                        </span>
                      </div>
                      <div>
                        <span className="font-medium">Fecha de cese:</span> 
                        <span className="ml-2">
                          {selectedStore.endDate 
                            ? new Date(selectedStore.endDate).toLocaleDateString() 
                            : "—"}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="border rounded-md p-4">
                    <h3 className="font-medium mb-3 border-b pb-2">Información de Contacto</h3>

                    <div className="space-y-2">
                      <div>
                        <span className="font-medium">Dirección:</span> 
                        <span className="ml-2">{selectedStore.address || "—"}</span>
                      </div>
                      <div>
                        <span className="font-medium">Teléfono:</span> 
                        <span className="ml-2">{selectedStore.phone || "—"}</span>
                      </div>
                      <div>
                        <span className="font-medium">Correo electrónico:</span> 
                        <span className="ml-2">{selectedStore.email || "—"}</span>
                      </div>
                    </div>
                  </div>

                  <div className="border rounded-md p-4">
                    <h3 className="font-medium mb-3 border-b pb-2">Información Empresarial</h3>

                    <div className="space-y-2">
                      <div>
                        <span className="font-medium">CIF:</span> 
                        <span className="ml-2">{selectedStore.cif || "—"}</span>
                      </div>
                      <div>
                        <span className="font-medium">Razón social:</span> 
                        <span className="ml-2">{selectedStore.businessName || "—"}</span>
                      </div>
                      <div>
                        <span className="font-medium">Propietario:</span> 
                        <span className="ml-2">{selectedStore.ownerName || "—"}</span>
                      </div>
                      <div>
                        <span className="font-medium">DNI Propietario:</span> 
                        <span className="ml-2">{selectedStore.ownerIdNumber || "—"}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {selectedStore.notes && (
                <div className="border rounded-md p-4 mt-4">
                  <h3 className="font-medium mb-3 border-b pb-2">Anotaciones</h3>
                  <p className="whitespace-pre-wrap text-sm">{selectedStore.notes}</p>
                </div>
              )}

              <DialogFooter className="mt-6">
                <Button 
                  variant="outline" 
                  onClick={() => setIsDetailDialogOpen(false)}
                >
                  Cerrar
                </Button>
                {canModify && (
                  <Button 
                    variant="outline"
                    className="ml-2"
                    onClick={() => {
                      setIsDetailDialogOpen(false);
                      setIsEditDialogOpen(true);
                    }}
                  >
                    <Pencil className="h-4 w-4 mr-1" />
                    Editar Tienda
                  </Button>
                )}
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Diálogo para ver archivos procesados de tienda */}
      <Dialog open={isRecordsDialogOpen} onOpenChange={setIsRecordsDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[85vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle>
              Archivos procesados: {selectedStore?.name} ({selectedStore?.code})
            </DialogTitle>
            <DialogDescription>
              Historial de archivos procesados para esta tienda
            </DialogDescription>
          </DialogHeader>

          <div className="overflow-auto max-h-[60vh] mt-4">
            {isLoadingActivities ? (
              <div className="py-8 flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              </div>
            ) : storeActivities.length === 0 ? (
              <div className="py-8 text-center">
                <p className="text-muted-foreground">No hay archivos disponibles para esta tienda</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Archivo</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {storeActivities.map((activity: any) => (
                      <tr key={activity.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {activity.filename}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <Badge 
                            variant={
                              activity.status === "Processed" ? "default" : 
                              activity.status === "Failed" ? "destructive" : 
                              "secondary"
                            }
                          >
                            {activity.status === "Processed" ? "Procesado" : 
                             activity.status === "Processing" ? "Procesando" :
                             activity.status === "Failed" ? "Error" : activity.status}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(activity.processingDate).toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <div className="flex space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8 w-8 p-0"
                              title="Descargar"
                              onClick={() => {
                                fetch(`/api/file-activities/${activity.id}/download`)
                                  .then(response => {
                                    if (!response.ok) {
                                      throw new Error('Error al descargar el archivo');
                                    }
                                    return response.blob();
                                  })
                                  .then(blob => {
                                    const url = window.URL.createObjectURL(blob);
                                    const a = document.createElement('a');
                                    a.style.display = 'none';
                                    a.href = url;
                                    a.download = activity.filename;
                                    document.body.appendChild(a);
                                    a.click();
                                    window.URL.revokeObjectURL(url);
                                    document.body.removeChild(a);
                                  })
                                  .catch(error => {
                                    toast({
                                      title: "Error",
                                      description: error instanceof Error ? error.message : "Error al descargar el archivo",
                                      variant: "destructive",
                                    });
                                  });
                              }}
                            >
                              <Download className="h-4 w-4" />
                              <span className="sr-only">Descargar</span>
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRecordsDialogOpen(false)}>
              Cerrar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}